# 🎮 Hangman Game System — C++

A fully-featured, terminal-based **Hangman Game** built in C++17 with player accounts, a scoring system, leaderboard, hints, difficulty levels, and six word categories.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔐 Player Accounts | Register, login, or play as Guest |
| 📂 6 Word Categories | Animals, Countries, Movies, Sports, Technology, Food |
| ⚙️ 3 Difficulty Levels | Easy (8 lives) · Medium (6 lives) · Hard (4 lives) |
| 🎨 ANSI Color UI | Colored terminal output with animated hangman |
| 🏆 Leaderboard | Top players ranked by total score |
| 📊 Stats Dashboard | Win rate, games played, recent history |
| 💡 Hint System | Reveal the word's clue for −20 points |
| 💾 Save System | Scores and history saved to disk automatically |
| 📖 Rules Screen | In-game instructions for new players |

---

## 📁 Project Structure

```
hangman/
├── include/
│   ├── Display.h         # UI / rendering declarations
│   ├── Game.h            # Core game logic declarations
│   ├── InputHandler.h    # Input validation declarations
│   ├── PlayerManager.h   # Player accounts & scores declarations
│   └── WordDatabase.h    # Word bank declarations
├── src/
│   ├── main.cpp          # Entry point & menu flow
│   ├── Display.cpp       # Terminal UI (hangman art, colors)
│   ├── Game.cpp          # Game rules, guess logic, scoring
│   ├── InputHandler.cpp  # Safe input handling
│   ├── PlayerManager.cpp # File-based save/load system
│   └── WordDatabase.cpp  # 60+ categorised words with hints
├── saves/                # Auto-created; stores player .dat files
├── CMakeLists.txt        # Cross-platform CMake build
├── Makefile              # Linux/macOS quick build
└── README.md
```

---

## 🚀 Build & Run

### Linux / macOS (Make)

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/hangman-cpp.git
cd hangman-cpp

# Build
make

# Run
./hangman

# Clean build files
make clean
```

### Cross-platform (CMake)

```bash
mkdir build && cd build
cmake ..
cmake --build .
./bin/hangman      # Linux/macOS
bin\hangman.exe    # Windows
```

### Windows (MinGW)

```cmd
g++ -std=c++17 -Iinclude src/*.cpp -o hangman.exe
hangman.exe
```

> **Requires:** g++ with C++17 support (GCC 8+ / Clang 7+ / MSVC 2019+)

---

## 🕹️ How to Play

1. **Register or Login** with your player name (progress is saved).
2. **Choose a category** — or pick *Any* for a random word.
3. **Choose difficulty** — Easy, Medium, or Hard.
4. **Guess letters** one at a time. Type a single letter and press Enter.
5. **Use a hint** by typing `H` (costs 20 points, one use per game).
6. **Quit to menu** at any time by typing `Q`.

### Scoring

| Action | Points |
|---|---|
| Correct guess | +10 |
| Wrong guess | −5 |
| Win bonus | +50 |
| Hint used | −20 |

---

## 📸 Screenshots

```
============================================================
                     HANGMAN GAME
============================================================
  +------+
  |      |
  |      O
  |     /|\
  |     / \
  |
  |
==========

  Category : Technology
  Player   : Rohit
  Score    : 25
  Lives    : ♥ ♥ ♡ ♡ ♡ ♡  (2/6)

  A L G O _ _ _ T H M

  Wrong letters: B C F K P

  [H] Use Hint (-20 pts)   [Q] Quit
============================================================
  >> Guess a letter: _
```

---

## 🛠️ Technical Details

- **Language:** C++17
- **Build:** CMake 3.14+ / GNU Make
- **Storage:** Plain-text `.dat` files in `saves/` directory
- **No external libraries** — standard library only
- **Platform:** Linux, macOS, Windows (with ANSI-capable terminal)

---

## 📝 License

MIT License — free to use, modify, and distribute.

---

> Built as a college project for System Analysis & Design / OOP coursework.
